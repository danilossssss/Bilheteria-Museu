#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


int n1,n2,n3,n4,n5,n6,total, i;
int a1, b1, c1, t1, a2, b2, c2, d2, m;
int a, b, c, d, md;

int main(int argc, char *argv[])

{





 printf("Seja bem vindo ao Museu!\n\nMENU\n\nDigite 1 para acessar Bilheteria\nDigite 2 para acessar Pesquisa de Satisfacao\n");
 scanf("%i", &i);
 
 switch (i)
 {
 	case 1:
 		system ("cls");
 	
 	system ("color 1f");
 
 
printf("Ingresso entrada inteira= R$10 reais\nMeia-entrada= R$5 reais\n\n");
      printf("\nDigite a quantidade de ingressos entrada inteira gostaria de comprar= ");
    scanf("%d", &n1);
    printf("Digite a quantidade de ingressos meia entrada gostaria de comprar= ");
    scanf("%d", &n2);  
    total=n1+n2; 
    printf("Total de ingressos= %d\n\n", total);  
   n3=n1 * 10;
   printf("Valor total dos ingressos entrada inteira = R$ %d\n",n3); 
   n4=n2 * 5;
   printf("Valor total dos ingressos meia entrada = R$ %d\n",n4);  
   n5=n3+n4;
   printf("Valor total = R$ %d\n", n5);
   
   FILE *file;
    file = fopen ("vendas.csv", "a");
    fprintf(file, "%d", n5);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
  printf("\nObrigado pela participacao!\n");
 	
  system ("pause");
 	
 	
 	break;
 	
 	
 	
 	case 2:
 			system ("cls");
 			
 	system ("color 80");

printf("Pesquisa de Satisfacao: \nAtribua notas de 0 a 10 ");
printf("\n\nQual nota atribui para Obra 150 anos de Santos Dumont? \nSua resposta = ");
scanf("%i", &a);

printf("\n\nQual nota atribui para 100 anos da semana de arte moderna? \nSua resposta = ");
scanf("%i", &b);

printf("\n\nQual nota atribui para Jogos ol�mpicos de Paris de 2024? \nSua resposta = ");
scanf("%i", &c);

printf("\n\nQual nota atribui para a Obra dos dinossauros? \nSua resposta = ");
scanf("%i", &d);

md=(a+b+c+d)/4;



printf("Media de Satisfacao= %i\n\n", md);




    file = fopen ("notas da pesquisa.csv", "a");
    fprintf(file, "%d", md);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
   
printf("Obrigado pela participacao! \n\n");
 	
  system ("pause");
  
 	
 	break;
 	
  	 default:	printf("\nVoce digitou uma caracatere invalido, digite novamente\n\n");
	 
  system ("pause");
 }
 
 	
 	
	system ("cls");
	
 	system ("color 07");
 printf("Seja bem vindo ao Museu!\n\nMENU\nDigite 1 para acessar Bilheteria\nDigite 2 para acessar Pesquisa de Satisfacao\n");
 scanf("%i", &i);
 
 switch (i)
 {
 	case 1:
 		system ("cls");
 	
 	system ("color 1f");
 
 
printf("Ingresso entrada inteira= R$10 reais\nMeia-entrada= R$5 reais\n\n");
      printf("\nDigite a quantidade de ingressos entrada inteira gostaria de comprar= ");
    scanf("%d", &n1);
    printf("Digite a quantidade de ingressos meia entrada gostaria de comprar= ");
    scanf("%d", &n2);  
    total=n1+n2; 
    printf("Total de ingressos= %d\n\n", total);  
   n3=n1 * 10;
   printf("Valor total dos ingressos entrada inteira = R$ %d\n",n3); 
   n4=n2 * 5;
   printf("Valor total dos ingressos meia entrada = R$ %d\n",n4);  
   n5=n3+n4;
   printf("Valor total = R$ %d\n", n5);
   
   FILE *file;
    file = fopen ("vendas.csv", "a");
    fprintf(file, "%d", n5);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
  printf("\nObrigado pela participacao!\n");
 	
 	
  system ("pause");
 	
 	
 	
 	
 	break;
 	
 	
 	
 	case 2:
 			system ("cls");
 			
 	system ("color 80");

printf("Pesquisa de Satisfacao: \nAtribua notas de 0 a 10 ");
printf("\n\nQual nota atribui para Obra 150 anos de Santos Dumont? \nSua resposta = ");
scanf("%i", &a);

printf("\n\nQual nota atribui para 100 anos da semana de arte moderna? \nSua resposta = ");
scanf("%i", &b);

printf("\n\nQual nota atribui para Jogos ol�mpicos de Paris de 2024? \nSua resposta = ");
scanf("%i", &c);

printf("\n\nQual nota atribui para a Obra dos dinossauros? \nSua resposta = ");
scanf("%i", &d);

md=(a+b+c+d)/4;



printf("Media de Satisfacao= %i\n\n", md);




    file = fopen ("notas da pesquisa.csv", "a");
    fprintf(file, "%d", md);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
   
printf("Obrigado pela participacao! \n\n");

  system ("pause");
  
 	
 	break;
 		 default:	printf("\nVoce digitou uma caracatere invalido, digite novamente\n\n");
  system ("pause");
 }
 
 
 	
	system ("cls");
	
 	system ("color 07");
 printf("Seja bem vindo ao Museu!\n\nMENU\nDigite 1 para acessar Bilheteria\nDigite 2 para acessar Pesquisa de Satisfacao\n");
 scanf("%i", &i);
 
 switch (i)
 {
 	case 1:
 		system ("cls");
 	
 	system ("color 1f");
 
 
printf("Ingresso entrada inteira= R$10 reais\nMeia-entrada= R$5 reais\n\n");
      printf("\nDigite a quantidade de ingressos entrada inteira gostaria de comprar= ");
    scanf("%d", &n1);
    printf("Digite a quantidade de ingressos meia entrada gostaria de comprar= ");
    scanf("%d", &n2);  
    total=n1+n2; 
    printf("Total de ingressos= %d\n\n", total);  
   n3=n1 * 10;
   printf("Valor total dos ingressos entrada inteira = R$ %d\n",n3); 
   n4=n2 * 5;
   printf("Valor total dos ingressos meia entrada = R$ %d\n",n4);  
   n5=n3+n4;
   printf("Valor total = R$ %d\n", n5);
   
   FILE *file;
    file = fopen ("vendas.csv", "a");
    fprintf(file, "%d", n5);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
  printf("\nObrigado pela participacao!\n");
 	
 	
  system ("pause");
 	
 	
 	
 	break;
 	
 	
 	
 	
 	case 2:
 			system ("cls");

 	system ("color 80");
printf("Pesquisa de Satisfacao: \nAtribua notas de 0 a 10 ");
printf("\n\nQual nota atribui para Obra 150 anos de Santos Dumont? \nSua resposta = ");
scanf("%i", &a);

printf("\n\nQual nota atribui para 100 anos da semana de arte moderna? \nSua resposta = ");
scanf("%i", &b);

printf("\n\nQual nota atribui para Jogos ol�mpicos de Paris de 2024? \nSua resposta = ");
scanf("%i", &c);

printf("\n\nQual nota atribui para a Obra dos dinossauros? \nSua resposta = ");
scanf("%i", &d);

md=(a+b+c+d)/4;



printf("Media de Satisfacao= %i\n\n", md);




    file = fopen ("notas da pesquisa.csv", "a");
    fprintf(file, "%d", md);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
   
printf("Obrigado pela participacao! \n\n");
 	
  system ("pause");
  
 	
 	break;
 	default:	printf("\nVoce digitou uma caracatere invalido, digite novamente\n\n");
  system ("pause");
 	
 }
 
 	system ("cls");
 	
 	system ("color 07");
 printf("Seja bem vindo ao Museu!\n\nMENU\n\nDigite 1 para acessar Bilheteria\nDigite 2 para acessar Pesquisa de Satisfacao\n");
 scanf("%i", &i);
 
 switch (i)
 {
 	case 1:
 		system ("cls");
 	
 	system ("color 1f");
 
 
printf("Ingresso entrada inteira= R$10 reais\nMeia-entrada= R$5 reais\n\n");
      printf("\nDigite a quantidade de ingressos entrada inteira gostaria de comprar= ");
    scanf("%d", &n1);
    printf("Digite a quantidade de ingressos meia entrada gostaria de comprar= ");
    scanf("%d", &n2);  
    total=n1+n2; 
    printf("Total de ingressos= %d\n\n", total);  
   n3=n1 * 10;
   printf("Valor total dos ingressos entrada inteira = R$ %d\n",n3); 
   n4=n2 * 5;
   printf("Valor total dos ingressos meia entrada = R$ %d\n",n4);  
   n5=n3+n4;
   printf("Valor total = R$ %d\n", n5);
   
   FILE *file;
    file = fopen ("vendas.csv", "a");
    fprintf(file, "%d", n5);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
  printf("\nObrigado pela participacao!\n");
 	
  system ("pause");
 	
 	
 	break;
 	
 	
 	
 	case 2:
 			system ("cls");

 	system ("color 80");
printf("Pesquisa de Satisfacao: \nAtribua notas de 0 a 10 ");
printf("\n\nQual nota atribui para Obra 150 anos de Santos Dumont? \nSua resposta = ");
scanf("%i", &a);

printf("\n\nQual nota atribui para 100 anos da semana de arte moderna? \nSua resposta = ");
scanf("%i", &b);

printf("\n\nQual nota atribui para Jogos ol�mpicos de Paris de 2024? \nSua resposta = ");
scanf("%i", &c);

printf("\n\nQual nota atribui para a Obra dos dinossauros? \nSua resposta = ");
scanf("%i", &d);

md=(a+b+c+d)/4;



printf("Media de Satisfacao= %i\n\n", md);




    file = fopen ("notas da pesquisa.csv", "a");
    fprintf(file, "%d", md);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
   
printf("Obrigado pela participacao! \n\n");
 	
  system ("pause");
  
 	
 	break;
 	
	 default:	printf("\nVoce digitou uma caracatere invalido, digite novamente\n\n");
  system ("pause");
 }
 
 	
 	
	system ("cls");
	
 	system ("color 07");
 printf("Seja bem vindo ao Museu!\n\nMENU\nDigite 1 para acessar Bilheteria\nDigite 2 para acessar Pesquisa de Satisfacao\n");
 scanf("%i", &i);
 
 switch (i)
 {
 	case 1:
 		system ("cls");
 	
 	system ("color 1f");
 
 
printf("Ingresso entrada inteira= R$10 reais\nMeia-entrada= R$5 reais\n\n");
      printf("\nDigite a quantidade de ingressos entrada inteira gostaria de comprar= ");
    scanf("%d", &n1);
    printf("Digite a quantidade de ingressos meia entrada gostaria de comprar= ");
    scanf("%d", &n2);  
    total=n1+n2; 
    printf("Total de ingressos= %d\n\n", total);  
   n3=n1 * 10;
   printf("Valor total dos ingressos entrada inteira = R$ %d\n",n3); 
   n4=n2 * 5;
   printf("Valor total dos ingressos meia entrada = R$ %d\n",n4);  
   n5=n3+n4;
   printf("Valor total = R$ %d\n", n5);
   
   FILE *file;
    file = fopen ("vendas.csv", "a");
    fprintf(file, "%d", n5);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
  printf("\nObrigado pela participacao!\n");
 	
 	
  system ("pause");
 	
 	
 	
 	
 	break;
 	
 	
 	
 	case 2:
 			system ("cls");

 	system ("color 80");
printf("Pesquisa de Satisfacao: \nAtribua notas de 0 a 10 ");
printf("\n\nQual nota atribui para Obra 150 anos de Santos Dumont? \nSua resposta = ");
scanf("%i", &a);

printf("\n\nQual nota atribui para 100 anos da semana de arte moderna? \nSua resposta = ");
scanf("%i", &b);

printf("\n\nQual nota atribui para Jogos ol�mpicos de Paris de 2024? \nSua resposta = ");
scanf("%i", &c);

printf("\n\nQual nota atribui para a Obra dos dinossauros? \nSua resposta = ");
scanf("%i", &d);

md=(a+b+c+d)/4;



printf("Media de Satisfacao= %i\n\n", md);




    file = fopen ("notas da pesquisa.csv", "a");
    fprintf(file, "%d", md);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
   
printf("Obrigado pela participacao! \n\n");

  system ("pause");
  
 	
 	break;
	 default:	printf("\nVoce digitou uma caracatere invalido, digite novamente\n\n");
  system ("pause");
 }
 
 
 	
	system ("cls");
	
 	system ("color 07");
 printf("Seja bem vindo ao Museu!\n\nMENU\nDigite 1 para acessar Bilheteria\nDigite 2 para acessar Pesquisa de Satisfacao\n");
 scanf("%i", &i);
 
 switch (i)
 {
 	case 1:
 		system ("cls");
 	
 
 	system ("color 1f");
 
printf("Ingresso entrada inteira= R$10 reais\nMeia-entrada= R$5 reais\n\n");
      printf("\nDigite a quantidade de ingressos entrada inteira gostaria de comprar= ");
    scanf("%d", &n1);
    printf("Digite a quantidade de ingressos meia entrada gostaria de comprar= ");
    scanf("%d", &n2);  
    total=n1+n2; 
    printf("Total de ingressos= %d\n\n", total);  
   n3=n1 * 10;
   printf("Valor total dos ingressos entrada inteira = R$ %d\n",n3); 
   n4=n2 * 5;
   printf("Valor total dos ingressos meia entrada = R$ %d\n",n4);  
   n5=n3+n4;
   printf("Valor total = R$ %d\n", n5);
   
   FILE *file;
    file = fopen ("vendas.csv", "a");
    fprintf(file, "%d", n5);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
  printf("\nObrigado pela participacao!\n");
 	
 	
  system ("pause");
 	
 	
 	
 	break;
 	
 	
 	
 	
 	case 2:
 			system ("cls");

 	system ("color 80");
printf("Pesquisa de Satisfacao: \nAtribua notas de 0 a 10 ");
printf("\n\nQual nota atribui para Obra 150 anos de Santos Dumont? \nSua resposta = ");
scanf("%i", &a);

printf("\n\nQual nota atribui para 100 anos da semana de arte moderna? \nSua resposta = ");
scanf("%i", &b);

printf("\n\nQual nota atribui para Jogos ol�mpicos de Paris de 2024? \nSua resposta = ");
scanf("%i", &c);

printf("\n\nQual nota atribui para a Obra dos dinossauros? \nSua resposta = ");
scanf("%i", &d);

md=(a+b+c+d)/4;



printf("Media de Satisfacao= %i\n\n", md);




    file = fopen ("notas da pesquisa.csv", "a");
    fprintf(file, "%d", md);
    fprintf(file, "\n");
    fclose(file);
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
   
printf("Obrigado pela participacao! \n\n");
 	
  system ("pause");
  
 	
 	break;
	 default:	printf("\nVoce digitou uma caracatere invalido, digite novamente\n\n");
  system ("pause");
 	
 }
 
 	system ("cls");
	system ("color f4");
 printf("Fim do sistema\n\nDigite 1 para acessar contabilidade\nDigite 2 para sair\n");
  scanf("%i", &i);
 	
 	switch (i)
 	{
	 
 	case 1:

 	system ("cls");
 	system ("color f1");
printf("Bem-vindo a Contabilidade do Museu\n\n Favor antes executar tres vezes os sistemas bilheteria e pesquisa de satisfacao, para gerar os dados que serao lidos aqui\n\n");


  
   FILE *file;
    file = fopen ("vendas.csv", "r");
   
   fscanf(file, "%d %d %d", &a1, &b1, &c1);
   printf("Dados de vendas:\nValor das vendas = %d %d %d", a1, b1, c1);
   
   
t1=a1+b1+c1;
   
   printf("\nSoma de todas as vendas = %d\n", t1);
   fclose(file);
   
  
  
  
    file = fopen ("notas da pesquisa.csv", "r");
   
   fscanf(file, "%d %d %d", &a2, &b2, &c2);
   printf("\nDados das pesquisas de satisfacao:\nMedias calculadas = %d %d %d", a2, b2, c2);
   
   
m=(a2+b2+c2)/3;
   
   printf("\nMedia geral = %d\n\n", m);
   fclose(file);
   
   
   
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
   

 		break;
 	
 		case 2:
 			printf("Ate logo\n");
 	break;
 	
	 default:	printf("\nVoce digitou uma caracatere invalido, digite novamente\n\n");
  system ("pause");
 	
 }
 
 
 
  
  system ("pause");
   
    return 0;
}
