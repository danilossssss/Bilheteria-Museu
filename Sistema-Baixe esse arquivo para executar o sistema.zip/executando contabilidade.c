#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {

int a1, b1, c1, t1, a2, b2, c2, d2, m;

printf("Bem-vindo a Contabilidade do Museu\n\n");

 FILE *file;
    file = fopen ("dados de vendas.csv", "r");
   
   fscanf(file, "%d %d %d", &a1, &b1, &c1);
   printf("Dados de vendas:\nValor das vendas = %d %d %d", a1, b1, c1);
   
   
t1=a1+b1+c1;
   
   printf("\nSoma de todas as vendas = %d\n", t1);
   fclose(file);
   
  
  
  
    file = fopen ("pesquisa.csv", "r");
   
   fscanf(file, "%d %d %d %d", &a2, &b2, &c2, &d2);
   printf("\nDados das pesquisas de satisfacao:\nMedias calculadas = %d %d %d %d", a2, b2, c2, d2);
   
   
m=(a2+b2+c2+d2)/4;
   
   printf("\nMedia geral = %d\n\n", m);
   fclose(file);
   
   
   
   
    if (file == NULL)
    {
        printf("arquivo n�o pode ser aberto");
    }
   
   
 
  system ("pause");
   
    return 0;
}
